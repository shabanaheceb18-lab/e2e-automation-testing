import { test, expect } from '@playwright/test';
import dotenv from 'dotenv';

dotenv.config();

test('has title FakeKart', async ({ page }) => {
  await page.goto('https://mern-e-commerce-front-end.vercel.app/login');

  // Expect a title "to contain" a substring.
  await expect(page).toHaveTitle(/FakeKart/);
});

test('execute login flow', async ({ page }) => {
    const userName = process.env.TEST_USERNAME;
    const password = process.env.TEST_PASSWORD;

    if (!userName || !password) {
        throw new Error('user name and password must be entered.');
    }
    await page.goto('https://mern-e-commerce-front-end.vercel.app/login');
    await page.getByRole('textbox', { name: 'Email' }).click();
    await page.getByRole('textbox', { name: 'Email' }).fill(userName);
    await page.getByRole('textbox', { name: 'Password' }).fill(password);
    await page.getByRole('button', { name: 'Login' }).click();

    await expect(page).toHaveURL('https://mern-e-commerce-front-end.vercel.app/');
    
});
test('execute invalid login flow', async ({ page }) => {
    const userName = process.env.INVALID_TEST_USERNAME;
    const password = process.env.INVALID_TEST_PASSWORD;

    if (!userName || !password) {
        throw new Error('user name and password must be entered.');
    }
    await page.goto('https://mern-e-commerce-front-end.vercel.app/login');
    await page.getByRole('textbox', { name: 'Email' }).click();
    await page.getByRole('textbox', { name: 'Email' }).fill(userName);
    // await page.getByRole('textbox', { name: 'Email' }).press('Tab');
    await page.getByRole('textbox', { name: 'Password' }).fill(password);
    // await page.getByLabel('Password').fill(password);
    await page.getByRole('button', { name: 'Login' }).click();
});
test('add product to cart', async ({ page }) => {
    const userName = process.env.TEST_USERNAME;
    const password = process.env.TEST_PASSWORD;
    const cardNumber = process.env.TEST_CARD;
    const mmyy = process.env.TEST_MMYY;
    const cvv = process.env.TEST_CVC;

    if (!userName || !password || !cardNumber || !mmyy || !cvv) {
        throw new Error('All fields must be entered.');
    }
    await page.goto('https://mern-e-commerce-front-end.vercel.app/login');
    await page.getByRole('textbox', { name: 'Email' }).click();
    await page.getByRole('textbox', { name: 'Email' }).fill(userName);
    
    await page.getByRole('textbox', { name: 'Password' }).fill(password);
    await page.getByRole('button', { name: 'Login' }).click();

    await expect(page).toHaveURL('https://mern-e-commerce-front-end.vercel.app/');
    await page.getByRole('button', { name: 'View More' }).nth(1).click();
    await expect(page).toHaveURL(/\/product\/?.*/);

    await page.getByRole('button', { name: 'Add to Cart' }).click();
    await page.getByRole('listitem').filter({ hasText: 'Cart1' });
});
test('view product in cart', async ({ page }) => {
    const userName = process.env.TEST_USERNAME;
    const password = process.env.TEST_PASSWORD;
    const cardNumber = process.env.TEST_CARD;
    const mmyy = process.env.TEST_MMYY;
    const cvv = process.env.TEST_CVC;

    if (!userName || !password || !cardNumber || !mmyy || !cvv) {
        throw new Error('All fields must be entered.');
    }
    await page.goto('https://mern-e-commerce-front-end.vercel.app/login');
    await page.getByRole('textbox', { name: 'Email' }).click();
    await page.getByRole('textbox', { name: 'Email' }).fill(userName);
    
    await page.getByRole('textbox', { name: 'Password' }).fill(password);
    await page.getByRole('button', { name: 'Login' }).click();

    await expect(page).toHaveURL('https://mern-e-commerce-front-end.vercel.app/');
    await page.getByRole('button', { name: 'View More' }).nth(1).click();
    await expect(page).toHaveURL(/\/product\/?.*/);

    await page.getByRole('button', { name: 'Add to Cart' }).click();
    await page.getByRole('listitem').filter({ hasText: 'Cart1' });
    
    await page.getByRole('button', { name: 'Go to Cart' }).click();
    await page.getByRole('button', { name: 'Checkout' }).click();

    await page.getByRole('textbox', { name: 'Email' }).fill(userName);
    await page.getByRole('textbox', { name: 'Card number' }).fill(cardNumber);
    await page.getByRole('textbox', { name: 'Expiration' }).fill(mmyy);
    await page.getByRole('textbox', { name: 'Credit or debit card CVC/CVV' }).fill(cvv);

    await page.getByRole('textbox', { name: 'Cardholder name' }).fill('adam');
    await page.getByTestId('hosted-payment-submit-button').click();

    await page.getByLabel('Country or region').selectOption('PH');


    await page.getByTestId('hosted-payment-submit-button').click();
    await page.getByRole('button', { name: 'Enter address manually' }).click();
    await page.getByRole('textbox', { name: 'Address line 1' }).click();
    await page.getByRole('textbox', { name: 'Address line 1' }).fill('123 west lane');
    await page.getByRole('textbox', { name: 'City' }).click();
    await page.getByRole('textbox', { name: 'City' }).fill('iwana');
    await page.getByRole('textbox', { name: 'Postal code' }).click();
    await page.getByRole('textbox', { name: 'Postal code' }).fill('12345');
    await page.getByLabel('Province').selectOption('Abra');
    await page.getByTestId('checkout-container').click();

    await page.getByTestId('hosted-payment-submit-button').click();
    await page.goto('https://mern-e-commerce-front-end.vercel.app/dashboard/user/success');

});